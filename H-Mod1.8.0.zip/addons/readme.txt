Install .VPK add-ons by placing them in this folder.

View and manage add-ons from the main menu: Extras->Add-ons.